

import React from "react";
import Data from './Task1/Data'

export default function  App(){
return(
  <div className="App">
  <Data/>
  </div>
)
}